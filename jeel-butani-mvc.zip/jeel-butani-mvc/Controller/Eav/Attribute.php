<?php 
class Controller_Eav_Attribute extends Controller_Core_Action
{
	public function gridAction()
	{
		try {
			$layout  = $this->getLayout();
			$grid = $layout->createBlock('Eav_Attribute_Grid');
			$layout->getChild('content')->addChild('grid',$grid);
			$layout->render();
		} catch (Exception $e) {
			$this->getMessage()->addMessage('Eav not showed.',Model_Core_Message:: FAILURE);
		}
	}
	public function addAction()
	{
		try {
			$layout = $this->getLayout();
			$eav_attribute = Ccc::getModel('Eav_Attribute');
	    	$add = $layout->createBlock('Eav_Attribute_Edit')->setData(['eav_attribute'=>$eav_attribute]);
			$layout->getChild('content')->addChild('add',$add);
			$layout->render();
		} catch (Exception $e) {
			$this->getMessage()->addMessage('Eav_Attribute not added.',Model_Core_Message:: FAILURE);
		}
	}
	
	public function editAction()
	{
		try {
			$eav_attribute_Id = (int) Ccc::getModel('Core_Request')->getParams('id');
			if (!$eav_attribute_Id) {
				throw new Exception("Invalid Id", 1);
			}
			$layout = $this->getLayout();
			$eav_attribute = Ccc::getModel('Eav_Attribute')->load($eav_attribute_Id);
			if (!$eav_attribute) {
				throw new Exception("Invalid Id", 1);
			}
			$edit = $layout->createBlock('Eav_Attribute_Edit')->setData(['eav_attribute'=>$eav_attribute]);
			$layout->getChild('content')->addChild('edit',$edit);
			$layout->render();
		} catch (Exception $e) {
			$this->getMessage()->addMessage('Eav_Attribute not edited.',Model_Core_Message:: FAILURE);
		}
	}
	public function saveAction()
	{
		try {
			if (!$this->getRequest()->isPost()) {
				throw new Exception("Invalid Request.", 1);
			}
			$postData = $this->getRequest()->getPost('eav_attribute');

			if ($id = $this->getRequest()->getParams('id')) 
			{	
					$eav_attribute = Ccc::getModel('Eav_Attribute')->load($id);
			}
			else
			{
				$eav_attribute = Ccc::getModel('Eav_Attribute');
			}
			$eav_attribute->setData($postData);
			$eav_attribute->save();
			// print_r($eav_attribute);
			// die();
			$this->getMessage()->addMessage('Attribute saved successfully.',Model_Core_Message::SUCCESS);
		} 
		catch (Exception $e) {
			$this->getMessage()->addMessage('Attribute not Saved.',Model_Core_Message::FAILURE);	
		}
		$this->redirect('grid','eav_attribute',null,true);
	}

	public function deleteAction()
	{
		try {
			if (!($id = (int)$this->getRequest()->getParams('id'))) {
				throw new Exception("Id not found", 1);
			}
			$eav_attribute = Ccc::getModel('Eav_Attribute')->load($id);
			if (!$eav_attribute) {
				throw new Exception("Eav_Attribute not found", 1);
			}
			$eav_attribute->delete();
			$this->getMessage()->addMessage('Eav_Attribute deleted.',Model_Core_Message:: SUCCESS);
		} catch (Exception $e) {
			$this->getMessage()->addMessage('Eav_Attribute not deleted.',Model_Core_Message:: FAILURE);
		}
	$this->redirect('grid','eav_attribute',null,true);
	}
}
?>