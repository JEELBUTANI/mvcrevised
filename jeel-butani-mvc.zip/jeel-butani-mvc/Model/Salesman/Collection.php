<?php

class Model_Vendor_Collection extends Model_Core_Table_Collection
{
	
}

?>