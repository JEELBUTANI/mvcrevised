<?php 

class Model_Eav_Attribute_Option_Collection extends Model_Core_Table_Collection
{
	
}