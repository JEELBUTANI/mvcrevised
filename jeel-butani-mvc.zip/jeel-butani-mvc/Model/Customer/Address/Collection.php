<?php

class Model_Customer_Address_Collection extends Model_Core_Table_Collection
{
	
}

?>