<?php 
class Block_Eav_Attribute_Grid extends Block_Core_Grid
{
	function __construct()
	{
		parent::__construct();
		$this->setTitle('Manage Attribute');
	}

	public function getCollection()
	{
		$query = "SELECT count('attribute_id') FROM `eav_attribute`";
		$totalRecord = Ccc::getModel('Core_Adapter')->fetchOne($query);
		
		$currentPage = Ccc::getModel('Core_Request')->getParams('p');
		$pager = Ccc::getModel('Core_Pagination');
		$pager->setCurrentPage($currentPage)->setTotalRecords($totalRecord);
		$pager->calculate();
		$this->setPager($pager);
		
		$query = "SELECT * FROM `eav_attribute` LIMIT {$pager->getStartLimit()},{$pager->getRecordPerPage()}";
		$eav_attribute = Ccc::getModel('Eav_Attribute')->fetchAll($query);
		return $eav_attribute;
	}

	public function _prepareColumns()
	{
		$this->addColumn('attribute_id',[
			'title'=>'Attribute_Id',
		]);
		$this->addColumn('entity_type_id',[
			'title'=>'Entity_Type_Id',
		]);
		$this->addColumn('code',[
			'title'=>'Code',
		]);
		$this->addColumn('backend_type',[
			'title'=>'Backend_Type',
		]);
		$this->addColumn('name',[
			'title'=>'Name',
		]);
		$this->addColumn('status',[
			'title'=>'Status',
		]);
		$this->addColumn('input_type',[
			'title'=>'Input_Type',
		]);
		return parent::_prepareColumns();
	}

	protected function _prepareActions()
	{
		$this->addAction('edit',['title' => 'Edit','method' => 'getEditUrl']);
		$this->addAction('delete',['title' => 'Delete','method' => 'getDeleteUrl']);
		return parent::_prepareActions();
	}

	public function _prepareButtons()
	{
		$this->addButton('attribute',[
			'title' => 'Add Attribute',
			'url' => $this->getUrl('add')
		]);
		return parent::_prepareButtons();
	}
}
?>